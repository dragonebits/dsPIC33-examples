/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.171.4
        Device            :  dsPIC33CH128MP506S1
    The generated drivers are tested against the following:
        Compiler          :  XC16 v2.10
        MPLAB 	          :  MPLAB X v6.05
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include "mcc_generated_files/system.h"



#define FCY 100000000UL              // Define instruction clock rate for delay routine //should be here!
#include <libpic30.h>               //For delay function definition


#define MACRO_PARTITIONSWAP() __asm__ volatile(" bclr INTCON2, #15 \n"  \
                                               " nop    \n"             \
                                               " nop    \n"             \
                                               " clr W0 \n"             \
                                               " mov #0x0055, W1 \n"    \
                                               " mov W1, NVMKEY  \n"    \
                                               " mov #0x00AA, W1 \n"    \
                                               " mov W1, NVMKEY  \n"    \
                                               " bootswp  \n"           \
                                               " call W0"  : : : "w0", "w1", "memory", "cc")  


/*
                         Main application
 */
int chk_key_input();

int main(void)
{
    // initialize the device
    
    if (!_SFTSWP){
      SYSTEM_Initialize();
    }
    SYSTEM_Initialize2();
    CCP1PRL = 0x1000;
     while (1)
    {
        // Add your application code
        Nop();
        Nop();
        __builtin_btg((uint16_t *) &LATB,14);
         __delay_us(1);
        if (chk_key_input()) {
            
            
            MACRO_PARTITIONSWAP();
        }
    }
    return 1; 
}


int chk_key_input(){
    if (_RB13==0){ //key input for swap partition
        __delay_ms(500); //wait until key debounce finsihed 
        while (_RB13==0); //waiting for release
        __delay_ms(500); //wait until key debounce finsihed 
        return (0x1);
        Nop();
        Nop();
    }
    return (0);
}    



void SCCP1_TMR_Timer32CallBack(void)
{
    // Add your custom callback code here
    Nop();
    Nop();
    __builtin_btg((uint16_t *) &LATD,5);
    Nop();
    Nop();
}


int __attribute__((optimize(1))) _crt_start_mode(void)
{
    Nop();
    Nop();
    return _SFTSWP;
}


void __attribute__((priority(100),optimize(1))) critical_init(void)
{
  //  while(1);
   if (_SFTSWP){
    _GIE = 1;
   }
   Nop();
   Nop();
}

/**
 End of File
*/
